# EVEREST — Zubin-Style Technical Architecture Flow

## Purpose

This document explains EVEREST in the same practical way developers understand the current Zubin/UDE flow.

It is intentionally written as an end-to-end product and backend story:

```text
Customer setup
→ data source onboarding
→ policy creation
→ policy execution
→ connector scan
→ batch processing
→ DSPM / classification
→ AI recommendation
→ Guardian decision
→ action execution or HITL
→ evidence / indexing / audit
```

The goal is that a customer, developer, QA engineer, architect, or manager can dry-run any scenario and understand:

- why the customer performs the action
- which component owns each step
- what input is passed
- what backend service handles it
- what database or storage is updated
- whether the storage is permanent or transient
- how scaling works for any number of files
- how customer data remains safe
- how future connectors and Data Agents are added

---

# 1. Simple EVEREST One-Line Architecture

```text
Portal asks.
Orchestrator plans.
Connector reads.
DSPM and AI understand.
Guardian decides.
Executor acts only if allowed.
Evidence proves.
```

More technically:

```text
Portal / Intent
  → Data Agent Cell Orchestrator
  → Generic Connector Adapter
  → Zero-Copy / Bounded Access
  → DuckDB transient working memory
  → DSPM / Classification / AI recommendation
  → Guardian decision
  → Approved Action Executor or HITL task
  → Decision provenance
  → PostgreSQL + Elasticsearch + Evidence package
```

---

# 2. Zubin to EVEREST Mapping

| Zubin concept | EVEREST equivalent | Notes |
|---|---|---|
| RBAC | RBAC / Role-aware Portal | User access to source, policy, evidence, actions |
| AD configuration | Identity / Directory configuration | AD / Entra / SSO / LDAP style integration |
| SLM configuration | Policy / governance / lifecycle configuration | Retention, classification, remediation, region control |
| Glossary configuration files | Business glossary / taxonomy / classification catalog | Used by DSPM and classification |
| Data science action | DSPM / AI / model configuration | Entity detection, recommendation, classification |
| Azure MIP configuration | Labeling / metadata / sensitivity label integration | For MIP or equivalent labeling systems |
| UDE server | Data Agent Cell | Component that runs close to customer data |
| UDE threadpool | Data Agent worker pool | Controlled concurrency for scan/action jobs |
| Add datastore and map with UDE | Register data source and map to Data Agent Cell | Source-to-agent assignment |
| Create policy | Policy as Code + workflow + assignment | Stored in PostgreSQL and signed artifact repo |
| Execute MDS policy | Execute metadata / quick scan policy | Runtime handled by Orchestrator |
| Policy Execution Service | Data Agent Cell Orchestrator | Mandatory runtime entry point |
| Send metadata batch of 1000 | Write normalized objects batch | Batch size configurable, default example 1000 |
| Indexing Service | Evidence/Search Publisher | Publishes normalized signals and evidence refs |
| Elastic | Elasticsearch | Search and analytics index |
| Postgres | PostgreSQL | Permanent system-of-record DB |

---

# 3. Exact Storage / Database Ownership

## 3.1 Storage map

| Storage / DB | Component owner | Permanent or transient | Stores | Should store raw customer content? |
|---|---|---|---|---|
| **PostgreSQL** | Control Plane | Permanent system of record | tenants, RBAC, sources, agents, policies, jobs, leases, HITL tasks, audit summary, evidence summary | No, not by default |
| **DuckDB** | Data Agent Cell | Transient local working memory | normalized objects, batch state, checkpoints, feature vectors, classification scores, action candidates, local rollups | No persistent full raw content by default |
| **Elasticsearch** | Search / Evidence Publisher | Rebuildable searchable index | normalized signals, classification summary, evidence references, action summaries, dashboard query data | No full raw content by default |
| **Git signed policy repository** | Policy / Conductor / Governance | Permanent policy artifact source | Policy as Code, Workflow as Code, signed compiled policy bundles, versions, hashes | No customer data |
| **Secret Manager / Vault / KMS** | Security / Platform | Permanent secret store | credential references, encrypted secrets, key material references | Secrets only, never exposed raw through UI |
| **Evidence Object Store** | Evidence Publisher / Control Plane | Permanent audit package store | manifest exports, provenance package, action receipts, evidence bundles | Only governed/redacted evidence unless explicit approved export |
| **Data Agent local cache** | Data Agent Cell / Item 13 | Local durable cache | active policy, Last Known Good policy, workflow cache, local runtime config snapshot | No full raw content by default |
| **Customer source system** | Customer | Permanent customer data store | actual files/objects/tables/documents | Yes, this is where customer data remains |

## 3.2 Recommended logical table/index names

These names should be treated as architecture contracts for discussion.

### PostgreSQL — Control Plane DB

| Logical table | Purpose |
|---|---|
| `tenants` | Customer tenant records |
| `users` | User identities |
| `roles` | RBAC roles |
| `role_assignments` | User-to-role mapping |
| `connector_catalog` | Supported connector types and capabilities |
| `data_sources` | Registered data stores such as Azure Blob, SMB, NFS |
| `agent_cells` | Registered Data Agent Cells |
| `source_agent_mappings` | Which Data Agent can access which source |
| `policy_definitions` | Policy metadata |
| `policy_assignments` | Policy attached to source/scope |
| `workflow_assignments` | Workflow attached to operation/policy |
| `jobs` | Requested operations |
| `leases` | Time-bound execution ownership |
| `hitl_tasks` | Human-in-the-loop review tasks |
| `audit_events` | System and user audit summary |
| `evidence_summaries` | Summary of produced evidence |
| `action_receipts` | Summary of action execution receipts |

### DuckDB — Data Agent transient working memory

| Logical table | Purpose |
|---|---|
| `execution_state` | Current local execution status |
| `batch_checkpoints` | Batch marker / resume information |
| `normalized_objects` | Connector-neutral object/file/table records |
| `feature_vectors` | Derived metadata/content features |
| `classification_results` | DSPM/classification output |
| `risk_scores` | Calculated risk per object/batch |
| `action_candidates` | Proposed actions before Guardian decision |
| `batch_rollups` | Aggregated batch metrics |
| `local_audit_draft` | Local evidence before publish |

### Elasticsearch — search and analytics index

| Index | Purpose |
|---|---|
| `everest-normalized-signals-*` | Searchable normalized metadata and classification signals |
| `everest-evidence-summary-*` | Evidence summaries for dashboard/query |
| `everest-action-results-*` | Action result search |
| `everest-provenance-*` | Searchable provenance references |
| `everest-risk-rollups-*` | Aggregated risk and posture rollups |

---

# 4. Terms and Definitions

| Term | Meaning |
|---|---|
| **RBAC** | Role-Based Access Control. Controls who can view, configure, execute, approve, or export. |
| **AD / Entra / Directory** | Identity source used to understand users, groups, ownership, and access context. |
| **DSPM** | Data Security Posture Management. Finds sensitive data, risky exposure, ownership gaps, policy violations, and remediation priority. |
| **HITL** | Human-in-the-loop. A human review task required before an action can continue. |
| **LKG** | Last Known Good. The last trusted policy/workflow artifact cached locally by the Data Agent. Used if latest policy fetch fails. |
| **Policy as Code** | Policy stored as versioned code/config, compiled/signed, and enforced consistently. |
| **Workflow as Code** | Execution workflow stored as versioned code/config. Defines operation steps. |
| **Guardian Agent** | Non-bypassable decision gate before mutation/export/destructive action. Allows, denies, modifies, or sends to HITL. |
| **Orchestrator** | Mandatory runtime entry point inside the Data Agent Cell. Plans execution, calls connectors, batches work, calls Guardian, publishes evidence. |
| **Connector Adapter** | Connector-specific implementation such as Azure Blob, SMB, NFS, SharePoint, OneDrive. Implements common connector contract. |
| **Normalized Object** | Standard representation of a file/object/document/table across connectors. |
| **Manifest** | Structured record of what was scanned/processed and what evidence was produced. |
| **Decision Provenance** | Proof of why a decision was made: policy hash, rules applied, actor, context, outcome, timestamp. |
| **Action Receipt** | Proof of an executed, blocked, failed, or skipped action. |
| **Zero-copy** | Practical definition: no persistent full duplicate copy of customer data by default. Reads happen by reference/handle/stream/range/bounded preview. |
| **No lock** | EVEREST does not lock the full customer source for scanning. It uses execution leases, checkpoints, and per-action idempotency instead. |
| **Lease** | Time-bound permission for a Data Agent to execute a specific job/scope. |
| **Checkpoint** | Saved progress marker used to resume large jobs. |
| **Backpressure** | Reducing processing speed when storage, network, memory, or indexing cannot keep up. |
| **Rate limiting** | Configured request limits to avoid overwhelming source systems. |
| **Idempotency** | Re-running an action should not duplicate unsafe effects. Achieved using action IDs, receipts, and object/version checks. |
| **ETag / Version ID** | Storage-native object version marker used to avoid applying actions to stale objects. |
| **NER** | Named Entity Recognition. Detects entities like person, organization, location, account number, student ID, etc. Optional model-based capability. |
| **MIP labeling** | Microsoft Information Protection / sensitivity labeling or equivalent classification label integration. |

---

# 5. MVS Items and Where They Fit

If we use item numbers, use the number and name consistently.

| Item | Name | Architecture responsibility |
|---|---|---|
| **Item 01 — Governed Policy Promotion** | Promote policy safely from draft to active | Policy lifecycle and approval |
| **Item 02 — Conductor Compilation Service** | Compile policy/workflow artifacts | Produces signed policy bundles |
| **Item 03 — Policy Hierarchy Resolution** | Resolve global, tenant, source, folder, object-level rules | Determines winning policy |
| **Item 04 — Data Store Policy Override** | Allow source/scope-specific policy overrides | Applies exceptions with governance |
| **Item 05 — Policy Governance UI** | UI for policy governance decisions | Human policy management |
| **Item 06 — Statistical Sampling Strategies** | Smart sampling for large datasets | Avoids full deep scan unless needed |
| **Item 07 — Quick Scan Analytics** | Fast metadata analytics | Metadata-only / low-cost visibility |
| **Item 08 — Classification Execution** | Execute classification policies | DSPM classification output |
| **Item 09 — Agent Core Execution State Initialization** | Initialize execution state | Orchestrator, lease, checkpoint setup |
| **Item 10 — Entity Frequency Aggregation** | Aggregate entity occurrence patterns | DSPM / NER rollups |
| **Item 11 — Compliance Achievement Reporting** | Report compliance progress and posture | Evidence dashboard and compliance view |
| **Item 12 — Decision Provenance Side Panel** | Explain decision trace | UI/UX for provenance |
| **Item 13 — Data Agent Local Resolution** | Local policy/workflow resolution and LKG | Item 13 Resolver inside Data Agent |
| **Item 14 — Content Intelligence Engine** | Feature extraction / NER / content intelligence | DSPM / AI / model integration |
| **Item 15 — Batch Summary Rollup** | Batch aggregation and summary | DuckDB rollups and Elasticsearch summary |

---

# 6. Product Setup Flow

This is similar to the Zubin install/config phase.

## 6.1 Customer/admin setup sequence

```text
1. Customer installs or deploys Data Agent Cell.
2. Platform Admin configures RBAC.
3. Platform Admin configures identity source such as AD / Entra.
4. Customer uploads or selects glossary/taxonomy.
5. Governance team configures Policy as Code.
6. Item 02 — Conductor Compilation Service compiles and signs policy/workflow artifacts.
7. Platform Admin configures DSPM/classification rules.
8. Optional AI/model provider is configured.
9. Optional labeling integration is configured.
10. Customer registers connectors and data sources.
11. Source is mapped to one or more Data Agent Cells.
```

## 6.2 Where setup information is stored

| Setup item | Stored in | Permanent/transient |
|---|---|---|
| RBAC users/roles | PostgreSQL | Permanent |
| Identity connector config | PostgreSQL + Secret Manager | Permanent |
| Glossary/taxonomy | PostgreSQL or signed artifact repo | Permanent |
| Policy metadata | PostgreSQL | Permanent |
| Signed policy artifact | Git signed policy repo | Permanent |
| AI/model provider config | PostgreSQL + Secret Manager | Permanent |
| Connector credential | Secret Manager / Vault / KMS | Permanent secret reference |
| Data source mapping | PostgreSQL | Permanent |
| Data Agent registration | PostgreSQL | Permanent |
| Active policy cache | Data Agent local cache | Local durable cache |
| LKG policy | Data Agent local cache | Local durable cache |

---

# 7. Data Store Onboarding Flow

## 7.1 Customer action

Customer adds a source:

```text
Connector: Azure Blob / SMB / NFS / SharePoint / OneDrive
Source: production source
Scope: container, share, library, folder, table, or prefix
Data Agent Cell: selected or auto-assigned
Credential: secret reference
```

## 7.2 Backend sequence

```text
1. Portal collects source input.
2. Portal sends source registration request to Control Plane.
3. Control Plane validates source fields.
4. Control Plane stores source record in PostgreSQL.
5. Secret is stored in Secret Manager; PostgreSQL stores only secret reference.
6. Source is mapped to Data Agent Cell.
7. Data Agent tests connector access.
8. Source becomes available for policies and scans.
```

## 7.3 Important safety rules

```text
Portal never displays raw secret after save.
Control Plane does not directly scan customer storage.
Data Agent Cell is the component that touches storage data.
Connector Adapter uses least-privilege credential.
```

---

# 8. Policy Creation Flow

## 8.1 User creates a policy

Example:

```text
Policy name: Finance Metadata Scan
Operation: Quick Scan / Metadata Scan
Scope: finance/payroll/
DSPM: enabled
AI recommendation: optional
Action mode: dry_run
Write-back: disabled
Sampling: metadata-only or smart sample
```

## 8.2 Backend flow

```text
1. Portal sends policy metadata to Control Plane.
2. Control Plane stores policy definition in PostgreSQL.
3. Policy as Code source is stored in Git.
4. Item 02 — Conductor Compilation Service compiles the policy.
5. Artifact is signed and hash is generated.
6. Policy assignment is stored in PostgreSQL.
7. Data Agent downloads/resolves signed artifact during execution.
8. Item 13 — Data Agent Local Resolution verifies artifact locally before using it.
```

## 8.3 Policy safety

```text
No unsigned policy should drive runtime execution.
No unknown policy should trigger mutation.
If latest policy is unavailable, use LKG only if it is trusted.
If no trusted LKG exists, block execution.
```

---

# 9. Universal Policy Execution Flow

Every operation should follow the same runtime path.

```text
Portal / Schedule / API
  → ActionRequestEnvelope
  → Data Agent Cell Orchestrator
  → Item 13 — Data Agent Local Resolution for policy/workflow resolution
  → Connector Adapter
  → Batch Engine
  → DuckDB transient working memory
  → DSPM / Classification / AI if needed
  → Guardian decision if action/export/mutation is possible
  → Action Executor or HITL task
  → Evidence Publisher
  → PostgreSQL + Elasticsearch + Evidence Object Store
```

## 9.1 ActionRequestEnvelope

Minimum contract:

```json
{
  "request_id": "req-001",
  "tenant_id": "tenant-a",
  "actor": "data-owner@example.com",
  "role": "Data Owner",
  "source_id": "finance-azureblob",
  "connector_id": "azure_blob",
  "operation": "metadata_scan",
  "intent": "Find sensitive payroll files",
  "scope": {
    "container": "finance",
    "prefix": "payroll/"
  },
  "policy_context": {
    "policy_id": "finance-metadata-policy"
  },
  "data_boundary": {
    "source_region": "IN",
    "target_region": "IN"
  },
  "correlation_id": "corr-001",
  "requested_at": "2026-06-18T10:00:00Z"
}
```

---

# 10. Metadata Scan / Quick Scan Flow

## 10.1 Why customer runs it

Customer wants fast visibility:

```text
What data exists?
Where is sensitive data likely present?
Who owns it?
Which areas need deeper scan?
```

## 10.2 How it works

```text
1. Orchestrator receives metadata_scan request.
2. Item 13 — Data Agent Local Resolution verifies policy/workflow.
3. Connector lists source objects.
4. Connector reads metadata, not full content.
5. Records are normalized.
6. DuckDB stores transient normalized objects.
7. Item 15 — Batch Summary Rollup calculates batch rollups.
8. Evidence/Search Publisher sends summary to Elasticsearch.
9. Portal shows dashboard and evidence.
```

## 10.3 Data read

| Connector | Metadata read |
|---|---|
| Azure Blob | blob name, size, content type, metadata, index tags, tier, timestamps |
| SMB/NFS | path, size, owner, permissions, timestamps, attributes |
| SharePoint/OneDrive | item name, library, owner, sharing, labels, permissions |
| Database | schema, table, column, row count, data type, access grants |
| API/Stream | endpoint/topic, schema, event size, sample availability |

## 10.4 Performance

```text
I/O-bound operation.
Uses pagination and worker pool.
Does not load all files into memory.
Default batch example: 1000 objects per batch.
```

---

# 11. Classification / DSPM Flow

## 11.1 Why customer runs it

Metadata alone tells what exists. Classification explains what it means.

DSPM answers:

```text
Is it sensitive?
Is it exposed?
Is it stale?
Is it over-shared?
Does it violate policy?
What should be done?
```

## 11.2 How classification works

Inputs:

```text
normalized metadata
path/name patterns
tags
permissions
bounded preview if allowed
sampled content if allowed
business glossary
policy rules
optional entity/model output
```

Outputs:

```text
classification label
sensitivity level
risk score
matched rules
entity summary
recommended action
```

Example output:

```json
{
  "object_id": "azureblob:finance:payroll/may.csv",
  "classification": "Payroll Data",
  "sensitivity": "High",
  "risk_score": 87,
  "matched_rules": ["payroll_path", "employee_identifier_pattern"],
  "recommended_action": "apply_metadata_tag"
}
```

---

# 12. Smart Sampling Flow

## 12.1 Why customer runs it

For millions of files, deep scanning everything is expensive.

Smart sampling selects representative or high-risk samples.

## 12.2 How it works

```text
1. Quick scan builds full metadata inventory.
2. Item 06 — Statistical Sampling Strategies selects samples.
3. Selection can use risk, file type, location, age, owner, size, randomness.
4. Connector performs bounded reads on selected samples.
5. Item 14 — Content Intelligence Engine extracts features.
6. DuckDB stores sample features and confidence metrics.
7. Evidence shows what was sampled and why.
```

## 12.3 Safety

```text
Sampling must be policy-controlled.
Raw sampled content should not be persisted by default.
Extracted features and redacted snippets are preferred.
```

---

# 13. Deep Scan Flow

## 13.1 Why customer runs it

Deep scan is used when a subset is high-risk or audit-critical.

## 13.2 How it works

```text
1. User selects scope or system recommends high-risk scope.
2. Orchestrator creates deep_scan execution plan.
3. Connector reads content by stream/range/bounded preview where policy allows.
4. Item 14 — Content Intelligence Engine extracts entities/features.
5. Classification and risk scores are updated.
6. AI may summarize findings.
7. Guardian is called before any remediation/export.
8. Evidence package records deep scan basis and result.
```

## 13.3 Performance impact

Deep scan is more CPU and I/O intensive.

Controls:

```text
max_sample_bytes
max_files_per_batch
max_parallel_readers
content_type allowlist
timeout per object
rate limiting
memory pool
```

---

# 14. AI Recommendation Flow

## 14.1 Where AI is configured

AI/model configuration is managed in Control Plane.

| Config | Stored in |
|---|---|
| AI provider type | PostgreSQL |
| Model name/profile | PostgreSQL |
| Endpoint URL | PostgreSQL or Secret Manager reference |
| API key/token | Secret Manager / Vault / KMS |
| Allowed operations | PostgreSQL policy config |
| Data boundary rules | Policy artifact |
| Max prompt/context size | PostgreSQL config |
| Redaction rules | Policy/DSPM config |
| Local/private/cloud mode | PostgreSQL deployment config |

## 14.2 How AI works

AI receives:

```text
redacted metadata
classification result
policy context
risk score
evidence references
allowed action catalog
```

AI can produce:

```text
summary
recommended tags
explanation
risk rationale
HITL task draft
next-best action
```

AI cannot:

```text
directly write tags
move data
delete data
change permissions
export content
bypass Guardian
```

## 14.3 Data safety for AI

```text
No raw full content is sent by default.
Policy controls whether bounded snippets/features can be sent.
Sensitive values should be redacted or tokenized.
Private/local model mode should be supported.
Every AI recommendation should be linked to evidence.
```

---

# 15. Guardian and Action Flow

## 15.1 When Guardian is called

Guardian is called:

```text
after enough context exists
before any mutation
before export/download of sensitive content
before region transfer
before destructive action
before permission change
```

## 15.2 Guardian input

```json
{
  "decision_id": "gd-001",
  "policy_bundle_version": "2026.06.01",
  "policy_bundle_hash": "sha256:abc",
  "actor": "data-owner@example.com",
  "operation": "apply_metadata_tag",
  "object_refs": ["azureblob:finance:payroll/may.csv"],
  "classification": "Payroll Data",
  "risk_score": 87,
  "source_region": "IN",
  "target_region": "IN",
  "recommended_action": {
    "type": "apply_metadata_tag",
    "tags": {
      "classification": "confidential"
    }
  }
}
```

## 15.3 Guardian output

```json
{
  "decision": "allow",
  "decision_id": "gd-001",
  "obligations": ["record_audit", "attach_policy_hash"],
  "hitl_required": false,
  "reasoning": "Safe metadata tagging is allowed by policy."
}
```

Possible decisions:

| Decision | Meaning |
|---|---|
| allow | Action may execute with obligations |
| deny/block | Action must not execute |
| modify | Action may execute only with changed scope/action |
| HITL | Human review is required |
| degraded | System cannot make safe decision, so mutation stops |

---

# 16. HITL Flow

## 16.1 HITL meaning

HITL means **Human-in-the-loop**.

The system cannot or should not proceed automatically.

Examples:

```text
high-risk file
region transfer
destructive action
policy conflict
low AI confidence
sensitive content export
permission change
```

## 16.2 HITL sequence

```text
1. Guardian returns HITL.
2. Orchestrator creates HITL task in PostgreSQL.
3. Portal shows task to approved role.
4. Human approves, rejects, or modifies.
5. Guardian/Orchestrator re-checks obligations.
6. Executor runs only if final decision allows.
7. Action receipt and provenance are recorded.
```

---

# 17. Evidence, Provenance, and Indexing Flow

## 17.1 What is published

| Output | Store |
|---|---|
| Execution summary | PostgreSQL |
| Normalized signals | Elasticsearch |
| Manifest summary | PostgreSQL + Evidence Object Store |
| Manifest details | Evidence Object Store / Elasticsearch reference |
| Guardian decisions | PostgreSQL + Elasticsearch provenance index |
| Action receipts | PostgreSQL + Evidence Object Store |
| Audit events | PostgreSQL |
| Evidence export package | Evidence Object Store |

## 17.2 Provenance must include

```text
actor
request_id
execution_id
policy bundle version
policy bundle hash
rules applied
decision
obligations
HITL flag
action receipt id
timestamp
signature/hash
```

---

# 18. Zero-Copy — How Exactly?

## 18.1 Practical definition

Zero-copy means:

```text
EVEREST does not create persistent full duplicate copies of customer data by default.
```

It does not mean the system never uses memory buffers. SDKs and streams may buffer chunks.

## 18.2 Allowed access patterns

```text
reference
handle
cursor
stream
range read
bounded preview
ephemeral feature extraction
metadata-only read
```

## 18.3 Not allowed by default

```text
persistent full file copy to Control Plane
bulk file movement to central system
unbounded raw content storage
sending raw sensitive content to AI by default
```

## 18.4 When full export/download is allowed

Only if:

```text
explicit user intent
Guardian approval
RBAC permission
audit record
provenance linkage
data boundary allowed
```

---

# 19. No Lock / No Queue — How Exactly?

## 19.1 No full source lock

EVEREST should not lock the entire data source for scanning.

It uses:

```text
job lease
batch checkpoint
object reference
idempotency key
storage-native version marker such as ETag/version ID
```

## 19.2 Where locking does happen

| Lock type | Purpose |
|---|---|
| Job lease | Ensures one agent owns an execution scope |
| Policy activation lock | Prevents half-applied policy activation |
| Checkpoint lock | Prevents corrupt local checkpoint update |
| Action idempotency key | Prevents duplicate mutation |
| Storage-native ETag/version check | Prevents write to stale object |

## 19.3 No external queue by default

EVEREST does not require queue/pub-sub for the core path.

Instead:

```text
Control Plane stores jobs and leases in PostgreSQL.
Data Agent polls or receives assigned lease.
Data Agent processes locally.
Status and evidence are published back.
```

Durable execution state is allowed. This is not the same as queue-first architecture.

---

# 20. Scaling Model

## 20.1 For any number of files

Example:

```text
Files = 2,000,000
Batch size = 1,000
Batches = 2,000
Workers = 16
In-flight batches = configurable
```

The Data Agent:

```text
does not load all files into memory
does not call Control Plane per file
does not send raw content to central system
does checkpoint per batch
does publish summary/evidence in bulk
```

## 20.2 I/O-bound vs CPU-bound

| Work | Type |
|---|---|
| Listing files/blobs | I/O-bound |
| Fetching metadata/tags/ACLs | I/O-bound |
| Range read / preview | I/O-bound |
| Writing to Elasticsearch | I/O-bound |
| Classification rules | CPU-bound |
| NER/entity extraction | CPU-bound |
| Hashing/signature verification | CPU-bound |
| AI/model calls | CPU/network-bound |
| Compression/export | CPU/I/O-bound |

## 20.3 Configuration knobs

```text
batch_size
max_workers
max_inflight_batches
max_memory_mb
max_sample_bytes
max_content_readers
connector_rate_limit
retry_backoff
checkpoint_interval
bulk_index_size
guardian_timeout
ai_timeout
```

## 20.4 Backpressure

If source, DuckDB, Guardian, AI, or Elasticsearch slows down:

```text
reduce worker concurrency
pause new batches
retry with backoff
keep checkpoint
mark degraded if needed
publish partial evidence
```

---

# 21. Adding a New Connector

## 21.1 New connector steps

```text
1. Add connector type to connector_catalog in PostgreSQL.
2. Implement Connector Adapter contract.
3. Define connector capabilities.
4. Define credential requirements.
5. Define source registration fields.
6. Implement discover/list/read metadata.
7. Implement normalized object mapping.
8. Implement supported actions.
9. Implement error model.
10. Add QA scenarios.
11. Register connector in UI.
12. Map source to Data Agent Cell.
```

## 21.2 Connector contract

Every connector must support:

```text
ValidateConnection()
DiscoverSources()
ListObjects()
ReadMetadata()
ReadFeatures()
NormalizeObject()
GetCapabilities()
ApplyApprovedAction()
ReturnEvidence()
```

## 21.3 Cross-connector communication

Connectors should not directly talk to each other.

For cross-connector operations:

```text
Source Connector
  → Orchestrator
  → Working memory / normalized object refs
  → Guardian decision
  → Target Connector
  → Action receipt
  → Evidence
```

Example:

```text
Azure Blob to SharePoint migration
```

Flow:

```text
Azure Blob Connector reads source references.
Orchestrator builds migration plan.
Guardian checks region, sensitivity, policy and target.
If allowed, target connector writes.
Evidence records both source and target refs.
```

---

# 22. Adding a New Data Agent Cell

## 22.1 Registration flow

```text
1. Install Data Agent Cell near customer data.
2. Agent generates identity or receives bootstrap token.
3. Agent registers with Control Plane.
4. Control Plane stores agent record in PostgreSQL.
5. Agent advertises capabilities.
6. Admin maps sources/connectors to agent.
7. Agent starts heartbeat.
8. Agent can receive leases.
```

## 22.2 Agent capabilities

```text
supported connectors
deployment mode
network zone
max workers
available memory
disk capacity
AI/model availability
local cache status
version
health
```

## 22.3 If agent dies

```text
heartbeat stops
lease expires
execution marked degraded/failed
checkpoint used for resume
new lease may be assigned
evidence records failure and recovery
```

---

# 23. Customer Data Safety

EVEREST maintains safety through layered controls.

## 23.1 Safety layers

```text
RBAC
least-privilege connector credentials
secret references instead of raw secrets
signed policy artifacts
Item 13 — Data Agent Local Resolution
LKG fallback
zero-copy default
bounded content reads
redaction before AI
Guardian before mutation
HITL for risky actions
action receipts
decision provenance
audit events
evidence package
```

## 23.2 Actions that must be guarded

```text
metadata/tag write-back
label change
permission change
archive
rehydrate
quarantine
copy
move
migration
delete
export/download
region transfer
```

## 23.3 Safe defaults

```text
dry-run by default
metadata-only scan by default
no full content persistence by default
no mutation without Guardian
no AI direct execution
no raw secret returned to UI
blocked attempts are still audited
```

---

# 24. Operation-by-Operation Summary

| Operation | Why customer does it | How backend does it | Guardian needed? |
|---|---|---|---|
| Inventory / Discovery | Know what sources/objects exist | Connector lists metadata and capabilities | No, unless export/action |
| Quick Scan | Fast metadata visibility | Metadata-only batch scan | No mutation, Guardian optional |
| Classification / DSPM | Understand sensitivity/risk | Rule/model classification on normalized signals | No mutation, Guardian optional |
| Smart Sample | Avoid deep scanning everything | Risk/statistical sample selection | No mutation unless export/action |
| Deep Scan | Inspect high-risk subset | Bounded content/features with policy | Required for export/action |
| AI Recommendation | Explain findings and next step | AI uses redacted context/evidence refs | AI cannot mutate; Guardian for actions |
| Safe Auto-Tagging | Automate low-risk remediation | AI/DSPM proposes tags, Guardian allows, executor writes | Yes |
| Region Transfer Review | Validate data movement | Guardian checks source/target boundary | Yes |
| Archive / Quarantine / Delete | Remediate risky data | Requires policy, HITL or allow, receipt | Yes |
| Evidence Export | Audit/compliance proof | Evidence package generation | Yes if sensitive export |
| Backup / Reset / Re-run | QA/recovery | Control Plane + local state reset/backup | Depends on action |

---

# 25. Final Developer Mental Model

Use this in team discussions:

```text
Zubin:
Portal configures → Policy Execution Service triggers → UDE scans → batch metadata → Indexing Service → Elasticsearch

EVEREST:
Portal configures → Orchestrator receives intent → Data Agent Cell runs connector workers → DuckDB stores transient batches → DSPM/AI understands → Guardian decides → Executor acts only if allowed → Evidence/Search Publisher writes PostgreSQL + Elasticsearch + Evidence package
```

Shortest version:

```text
Intent → Orchestrator → Connector → DuckDB → DSPM/AI → Guardian → Action/HITL → Evidence
```
